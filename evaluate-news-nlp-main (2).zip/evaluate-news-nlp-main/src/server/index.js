var path = require('path');
const express = require('express');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const axios = require('axios'); // Import axios for API requests

dotenv.config();

const app = express();

const cors = require('cors');

app.use(cors());
app.use(bodyParser.json());

console.log(__dirname);

// Variables for URL and API key
const aylienAPIKey = process.env.AYLIEN_API_KEY;
const aylienAppID = process.env.AYLIEN_APP_ID;

// Root route
app.get('/', function (req, res) {
    res.send("This is the server API page, you may access its services via the client app.");
});

// POST Route to handle text analysis
app.post('/api/analyze', (req, res) => {
    const { text } = req.body; // Get text from the client

    axios.post('https://api.aylien.com/api/v1/text-analysis', {
        text: text
    }, {
        headers: {
            'X-AYLIEN-TextAPI-Application-Key': aylienAPIKey,
            'X-AYLIEN-TextAPI-Application-ID': aylienAppID
        }
    })
    .then(response => {
        res.send(response.data); // Send API response back to the client
    })
    .catch(error => {
        res.status(500).send(error.message); // Handle errors
    });
});

// Designates what port the app will listen to for incoming requests
app.listen(8000, function () {
    console.log('Example app listening on port 8000!');
});
